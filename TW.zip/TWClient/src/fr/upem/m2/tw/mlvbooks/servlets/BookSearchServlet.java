package fr.upem.m2.tw.mlvbooks.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;

import fr.upem.m2.tw.mlvbooks.objects.beans.LightBook;
import fr.upem.m2.tw.mlvbooks.objects.dto.LightBookDTO;
import fr.upem.m2.tw.mlvbooks.objects.dto.SearchParametersDTO;
import fr.upem.m2.tw.mlvbooks.services.Library;
import fr.upem.m2.tw.mlvbooks.utils.LibraryAccessor;
import fr.upem.m2.tw.mlvbooks.utils.SearchParametersFactory;

/**
 * 
 * 
 * @author Mathieu ABOU-AICHI (mathieu.abouaichi@gmail.com)
 */
@WebServlet("/BookSearchServlet")
public class BookSearchServlet extends HttpServlet {
  /**
   * Serial UID.
   */
  private static final long serialVersionUID = 6202802310406217956L;
  private Library library = null; // late binding
  private Mapper mapper;

  /**
   * Default constructor.
   */
  public BookSearchServlet() {
    super();
    mapper = new DozerBeanMapper();
  }

  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    library = LibraryAccessor.getLibraryAccess();
    if (library == null) {
      request.setAttribute(
          "errorMessage",
          "An error has occured, please try again later.");
    } else {
      SearchParametersDTO searchParameters = SearchParametersFactory
          .createSearchParametersDTO(request.getParameterMap());
      List<LightBookDTO> books = library.searchBook(searchParameters);
      if (books.isEmpty()) {
        request.setAttribute("result", "No books found.");
      } else {
        List<LightBook> beanBooks = new ArrayList<>();
        mapper.map(books, beanBooks);
        request.setAttribute("books", beanBooks);
      }
      RequestDispatcher requestDispatcher = request
          .getRequestDispatcher("index.jsp");
      if (requestDispatcher != null) {
        requestDispatcher.forward(request, response);
      }
    }
  }

  private void initLibrary() {
    
  }
  
  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // TODO Auto-generated method stub
  }

}
