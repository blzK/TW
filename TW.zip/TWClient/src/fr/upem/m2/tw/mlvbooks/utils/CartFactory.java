package fr.upem.m2.tw.mlvbooks.utils;

import java.rmi.RemoteException;
import java.util.Arrays;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;

import fr.upem.m2.tw.mlvbooks.objects.beans.Cart;
import fr.upem.m2.tw.mlvbooks.objects.beans.LightBook;
import fr.upem.m2.tw.mlvbooks.objects.dto.LightBookDTO;
import fr.upem.m2.tw.mlvbooks.services.Library;

/**
 * A cart builder.
 * 
 * @author Mathieu ABOU-AICHI (mathieu.abouaichi@gmail.com)
 */
public final class CartFactory {
  private CartFactory() {}
  
  /**
   * Builds the cart.
   * 
   * @param ids the books' ids.
   * @return the cart.
   */
  public static Cart getCart(String ids) {
    Cart bookMap = new Cart();
    Library library = LibraryAccessor.getLibraryAccess();
    Mapper mapper = new DozerBeanMapper();
    CharSequence idSequence = ids.subSequence(1, ids.length() - 1);
    List<String> idList = Arrays.asList(idSequence.toString().split(","));
    for (String id : idList) {
      try {
        LightBookDTO bookDto = library.searchLightBookById(Long.parseLong(id));
        if (bookDto != null) {
          LightBook book = mapper.map(
              library.searchLightBookById(Long.parseLong(id)),
              LightBook.class);
          bookMap.put(
              book,
              bookMap.containsKey(book) ? bookMap.get(book) + 1 : 1);
        }
      } catch (NumberFormatException e) {
      } catch (RemoteException e) {
      }
    }
    return bookMap;
  }
}
