package fr.upem.m2.tw.mlvbooks.utils;

import java.nio.file.Paths;
import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.util.Scanner;

import fr.upem.m2.tw.mlvbooks.services.Library;

/**
 * Library accessor util class.
 * 
 * @author Mathieu ABOU-AICHI (mathieu.abouaichi@gmail.com)
 */
public final class LibraryAccessor {
  private static Library library = null;
  
  private LibraryAccessor() {}
  
  public static final Library getLibraryAccess() {
    if (library == null) {
      try {
        String policyFile = "";
        String codebase = "";
        System.out.println(Paths.get("").toAbsolutePath());
        try (Scanner scanner = new Scanner(Paths.get("libraryAccess.txt"))) {
          while (scanner.hasNext()) {
            policyFile = scanner.next();
            codebase = scanner.next();
          }
        }
        System.setProperty("java.security.policy", policyFile);
        System.setProperty("java.rmi.server.codebase", codebase);
        System.setSecurityManager(new RMISecurityManager());
        library = (Library) Naming.lookup("rmi://localhost:1099/LibraryService");
      } catch (Exception exception) {
        System.err.println("Trouble : " + exception);
        return null;
      } 
    }
    return library;
  }
}
