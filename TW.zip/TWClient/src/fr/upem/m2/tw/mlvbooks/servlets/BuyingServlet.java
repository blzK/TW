package fr.upem.m2.tw.mlvbooks.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.rpc.ServiceException;

import bank.BankAccount;
import bank.BankAccountServiceLocator;
import bank.BankAccountSoapBindingStub;

/**
 * Servlet implementation class BuyingServlet
 */
@WebServlet("/BuyingServlet")
public class BuyingServlet extends HttpServlet {

  /**
   * Serial UID.
   */
  private static final long serialVersionUID = 5538769645664135031L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public BuyingServlet() {
    super();
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // unused
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    double cost = Double.parseDouble(request.getParameter("cost"));
    BankAccount account = null;
    try {
      account = new BankAccountServiceLocator().getBankAccount();
      ((BankAccountSoapBindingStub) account).setMaintainSession(true); 
      account.pay(cost, "EUR");
      request.setAttribute("newBalance", account.getBalance());
    } catch (ServiceException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    RequestDispatcher requestDispatcher = 
        request.getRequestDispatcher("index.jsp");
    if (requestDispatcher != null) {
      requestDispatcher.forward(request, response);
    }
  }

}
