import java.rmi.Naming;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import fr.upem.m2.tw.mlvbooks.objects.dto.HeavyBookDTO;
import fr.upem.m2.tw.mlvbooks.services.Library;

/**
 * Server main class.
 * 
 * @author Alexandre SALIMI
 */
public class LibraryServer {
  public static void main(String[] args) {
    try {
      Library library = new LibraryImp();
      Map<Long, HeavyBookDTO> books = new ConcurrentHashMap<>();
      for (int i = 0; i < 10; i++) {
        HeavyBookDTO book = BookCreator.createBook();
        books.put(book.getId(), book);
      }
      ((LibraryImp) library).setBooks(books);
      Naming.rebind("rmi://localhost:1099/LibraryService", library);
    } catch (Exception exception) {
      System.err.println("Trouble : " + exception);
    }
  }
}
