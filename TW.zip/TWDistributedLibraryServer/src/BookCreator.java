import fr.upem.m2.tw.mlvbooks.objects.dto.HeavyBookDTO;

public final class BookCreator {
  private BookCreator() {}
  
  public static HeavyBookDTO createBook() {
    HeavyBookDTO book = new HeavyBookDTO();
    Long id = createId();
    book.setId(id);
    book.setISBN(id.toString());
    book.setTitle("Book " + id);
    book.setAuthor("Author " + id);
    book.setSynopsis("This is the synopsis of the book " + id);
    book.setNumberOfPages(42);
    book.setPrice(19.99);
    return book;
  }
  
  private static Long createId() {
    return System.nanoTime();
  }
}
