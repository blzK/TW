

import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

import fr.upem.m2.tw.mlvbooks.objects.dto.HeavyBookDTO;
import fr.upem.m2.tw.mlvbooks.objects.dto.LightBookDTO;
import fr.upem.m2.tw.mlvbooks.objects.dto.SearchParametersDTO;
import fr.upem.m2.tw.mlvbooks.services.Library;

/**
 * Library service implementation.
 * 
 * @author Alexandre SALIMI
 */
public class LibraryImp extends UnicastRemoteObject implements Library,
    Serializable {

  /**
   * Serial UID
   */
  private static final long serialVersionUID = 899577144233055923L;

  private Map<Long, HeavyBookDTO> books;

  protected LibraryImp() throws RemoteException {
    super();
    books = new ConcurrentHashMap<>();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public boolean addBook(Long id, String title, String author)
      throws RemoteException {
    Objects.requireNonNull(id);
    HeavyBookDTO book = new HeavyBookDTO();
    book.setId(id);
    book.setAuthor(author);
    book.setTitle(title);
    if (books.containsKey(book.getId()))
      return false;
    books.put(book.getId(), book);
    return true;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public boolean addExistingBook(HeavyBookDTO book) throws RemoteException {
    Objects.requireNonNull(book.getId());
    if (books.containsKey(book.getId()))
      return false;
    books.put(book.getId(), book);
    return true;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void remove(Long id) throws RemoteException {
    books.remove(id);
  }

  @Override
  public LightBookDTO searchLightBookById(Long id) throws RemoteException {
    if (books.isEmpty() || id == null) {
      return null;
    }
    HeavyBookDTO heavyBook = books.get(id);
    if (heavyBook == null) {
      return null;
    }
    return createLightBook(heavyBook);
  }

  @Override
  public HeavyBookDTO searchHeavyBookById(Long id) throws RemoteException {
    if (books.isEmpty() || id == null) {
      return null;
    }
    return books.get(id);
  }

  @Override
  public List<LightBookDTO> searchByTitle(String title) throws RemoteException {
    List<LightBookDTO> results = new ArrayList<>();
    if (books.isEmpty() || title == null)
      return results;
    for (Long elementId : books.keySet()) {
      HeavyBookDTO book = books.get(elementId);
      if (book.getTitle().contains(title)) {
        
        results.add(createLightBook(book));
      }
    }
    return results;
  }

  private LightBookDTO createLightBook(HeavyBookDTO heavyBookDTO) {
    LightBookDTO book = new LightBookDTO();
    book.setId(heavyBookDTO.getId());
    book.setAuthor(heavyBookDTO.getAuthor());
    book.setTitle(heavyBookDTO.getTitle());
    book.setPrice(heavyBookDTO.getPrice());
    return book;
  }
  
  @Override
  public List<LightBookDTO> searchByAuthor(String author)
      throws RemoteException {
    List<LightBookDTO> results = new ArrayList<>();
    if (books.isEmpty() || author == null)
      return results;
    for (Long elementId : books.keySet()) {
      HeavyBookDTO book = books.get(elementId);
      if (book.getAuthor().contains(author))
        results.add(createLightBook(book));
    }
    return results;
  }

  @Override
  public List<LightBookDTO> searchByISBN(String ISBN) throws RemoteException {
    List<LightBookDTO> found = new ArrayList<>();
    if (books.isEmpty() || ISBN == null)
      return found;
    for (Long elementId : books.keySet()) {
      HeavyBookDTO book = books.get(elementId);
      if (book.getISBN().contains(ISBN)) {
        found.add(createLightBook(book));
      }
    }
    return found;
  }

  @Override
  public List<LightBookDTO> searchBook(SearchParametersDTO searchParametersDTO)
      throws RemoteException {
    if (searchParametersDTO == null || books == null) {
      return null;
    }
    List<LightBookDTO> found = new ArrayList<>();
    for (Long elementId : books.keySet()) {
      HeavyBookDTO book = books.get(elementId);
      if ((searchParametersDTO.getAuthor() != null && book.getAuthor().contains(searchParametersDTO.getAuthor()))
          || (searchParametersDTO.getTitle() != null && book.getTitle().contains(searchParametersDTO.getTitle()))
          || (searchParametersDTO.getISBN() != null && book.getISBN().contains(searchParametersDTO.getISBN()))) {
        found.add(createLightBook(book));
      }
    }
    return found;
  }

  public Map<Long, HeavyBookDTO> getBooks() {
    return books;
  }

  public void setBooks(Map<Long, HeavyBookDTO> books) {
    this.books = books;
  }
}
